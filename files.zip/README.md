# Physically-Grounded Crack Spread Trading Strategy

> A mean-reversion statistical arbitrage strategy on refinery crack spreads, where product yield weights are derived from an Aspen HYSYS atmospheric crude distillation simulation rather than the generic 3:2:1 textbook ratio.

---

## The Differentiator

Most crack spread models use this:

```
Crack Spread = (2/3 × Gasoline + 1/3 × Heating Oil) − Crude
```

This project uses this instead:

```
Margin = (yield_naphtha × RBOB × 42) + (yield_diesel × HO × 42) − WTI − utility_cost_per_bbl
```

Where `yield_naphtha = 0.0342` and `yield_diesel = 0.1223` are derived from an actual Aspen HYSYS CDU simulation of a WTI Light crude assay — not assumed from a textbook. The utility cost per barrel ($0.112/bbl) comes from the HYSYS Economic Analysis module.

This gives the strategy a **physical basis**: the spread mean-reverts because refinery economics are anchored to real process thermodynamics and capital constraints, not because of a statistical artefact.

---

## Project Structure

```
refinery-margin-strategy/
├── hysys/
│   ├── CDU_flowsheet_screenshot.png    # Converged HYSYS flowsheet
│   ├── yield_output.csv                # Product stream mass flows
│   └── economics_output.csv           # Utility costs from HYSYS Economics
├── data/
│   └── raw_prices.csv                 # Cached yfinance pulls (auto-generated)
├── notebooks/
│   ├── 01_data_pipeline.ipynb         # yfinance data pull
│   ├── 02_spread_construction.ipynb   # HYSYS-weighted crack spread
│   ├── 03_stationarity_ou_fit.ipynb   # ADF/KPSS tests + OU parameter estimation
│   └── 04_backtest.ipynb              # Signal generation + backtest + metrics
├── src/
│   └── signal_generator.py            # Reusable signal generation functions
├── README.md
└── requirements.txt
```

---

## Part 1: HYSYS Process Simulation

### Flowsheet Overview

An atmospheric crude distillation unit (CDU) was built in Aspen HYSYS using a published WTI Light crude assay from ExxonMobil:

```
Raw Crude (25°C, 200 kPa, 10,000 kg/h)
    ↓
PreFlash Separator (V-100)        → PreFlash Vapour (light ends)
    ↓
Crude Heater (→ 350°C)
    ↓
Mixer + Feed Valve
    ↓
T-100 Atmospheric Column (28 stages, Partial Condenser)
    ├── Off Gas          268.1 kg/h   (2.9%)
    ├── Naphtha          319.7 kg/h   (3.4%)   ← maps to RB=F (RBOB)
    ├── Kerosene         1,096 kg/h   (11.7%)
    ├── Diesel           1,142 kg/h   (12.2%)  ← maps to HO=F (Heating Oil)
    ├── AGO              1,172 kg/h   (12.6%)
    └── Residue          5,353 kg/h   (57.3%)
```

### Key Simulation Parameters

| Parameter | Value | Source |
|-----------|-------|--------|
| Crude grade | WTI Light | ExxonMobil EMTEC assay WTIL220Y |
| API Gravity | 47.5 | ExxonMobil published assay |
| Fluid package | Peng-Robinson | Industry standard for petroleum |
| Feed conditions | 25°C, 200 kPa, 10,000 kg/h | — |
| Column stages | 28 (Refluxed Absorber) | — |
| Condenser type | Partial | — |
| Side strippers | Kerosene (reboiled), Diesel (steam), AGO (steam) | — |
| Utility cost/bbl | $0.112 | HYSYS Activated Economics |

### HYSYS-Derived Yield Fractions (used directly in Python)

```python
yield_naphtha        = 319.7  / 9336   # = 0.0342
yield_kerosene       = 1096   / 9336   # = 0.1174
yield_diesel         = 1142   / 9336   # = 0.1223
yield_ago            = 1172   / 9336   # = 0.1255
yield_residue        = 5353   / 9336   # = 0.5733
utility_cost_per_bbl = 0.112           # USD/bbl (from HYSYS Economics)
```

---

## Part 2: Quantitative Strategy

### Data Sources

| Instrument | Ticker | Role |
|------------|--------|------|
| WTI Crude | `CL=F` | Feedstock cost ($/bbl) |
| RBOB Gasoline | `RB=F` | Naphtha/gasoline product proxy ($/gallon) |
| Heating Oil | `HO=F` | Diesel product proxy ($/gallon) |

### The Spread Formula

```python
# Unit conversion: RBOB and HO are quoted $/gallon → ×42 converts to $/bbl
margin = (yield_naphtha * RBOB * 42) \
       + (yield_diesel  * HO   * 42) \
       - WTI \
       - utility_cost_per_bbl
```

### Statistical Framework

**Stationarity validation:**
- Augmented Dickey-Fuller (ADF) test — rejects unit root
- KPSS test — confirms stationarity
- Both tests required to confirm mean-reversion is a real, persistent property

**Ornstein-Uhlenbeck process fit:**

```
dX(t) = θ(μ − X(t))dt + σdW(t)
```

| Parameter | Description |
|-----------|-------------|
| θ (theta) | Mean reversion speed |
| μ (mu) | Long-run equilibrium margin |
| σ (sigma) | Volatility |
| Half-life | ln(2)/θ — practical trading horizon in days |

### Trading Signal

```python
entry_threshold = 1.5   # standard deviations
exit_threshold  = 0.0   # revert to mean

# Long when spread unusually compressed (refiners squeezed)
# Short when spread unusually wide (refiners over-earning)
```

### Operational Inertia Friction Term

A refinery cannot instantly change its yield slate — feed heaters, column pressures, and draw configurations take time to adjust. A minimum holding period of **5 days** is enforced between signal changes, derived directly from the process engineering constraints modelled in the HYSYS simulation. This is the key distinguishing feature of this backtest vs a generic statistical arbitrage model.

### Performance Metrics Reported

- Total return ($/bbl)
- Sharpe ratio (annualised)
- Maximum drawdown ($/bbl)
- Win rate
- Number of round-trip trades
- Equity curve plot

---

## Results

*(Populate after running notebooks)*

| Metric | Value |
|--------|-------|
| Sharpe Ratio | — |
| Total Return | — |
| Max Drawdown | — |
| Win Rate | — |
| Half-life (days) | — |

---

## Setup & Usage

### Requirements

```bash
pip install -r requirements.txt
```

### Run notebooks in order

```bash
jupyter notebook
```

1. `01_data_pipeline.ipynb` — pulls price data from Yahoo Finance
2. `02_spread_construction.ipynb` — builds the HYSYS-weighted margin series
3. `03_stationarity_ou_fit.ipynb` — validates mean reversion, fits OU parameters
4. `04_backtest.ipynb` — generates signals, runs backtest, plots results

---

## Data Sources & Citations

**Crude Assay:**
> ExxonMobil Technology & Engineering Company (EMTEC). *Crude Summary Report — WTI Light (Reference WTIL220Y).* Published October 23, 2020.
> Available at: https://corporate.exxonmobil.com/crude-oils/crude-trading/assays-available-for-download

**Refinery yield methodology:**
> Jechura, J. (2019). *Refinery Feedstocks & Products: Properties & Specifications.* CBEN 409 – Petroleum Refining, Colorado School of Mines.
> Available at: https://people.mines.edu/jjechura

**HYSYS simulation methodology:**
> AspenTech. (2014). *EHY101 Aspen HYSYS: Process Modeling — Customer Education Training Manual (Course EHY101.086.01).* AspenTech, Inc.

**Market data:**
> Yahoo Finance via `yfinance` Python library. Tickers: CL=F, RB=F, HO=F.

---

## Technical Stack

| Tool | Purpose |
|------|---------|
| Aspen HYSYS | CDU process simulation + yield extraction |
| Python 3.x | Strategy implementation |
| pandas / numpy | Data manipulation |
| statsmodels | ADF/KPSS stationarity tests |
| scipy | OU parameter estimation (MLE) |
| yfinance | Commodity futures price data |
| matplotlib | Visualisation |
| Jupyter Notebook (Anaconda) | Development environment |

---

## Author

Chemical Engineering student, University of Nottingham (Year 3).
Pivoting to quantitative finance — building a portfolio that combines process engineering domain knowledge with systematic trading methodology.

Target roles: Quantitative Researcher / Trader at energy-focused systematic funds.
