# Crack Spread Trading Strategy — Full Project Brief & Part 2 Continuation Prompt

---

## WHO I AM
I am a Chemical Engineering student at the University of Nottingham entering my third year. I am actively pivoting toward quantitative finance and applying to firms including Citadel, Optiver, Jane Street, G-Research, Qube/Man Group, and Winton. My primary application cycle is September–November 2026. I have strong experience in Aspen HYSYS (NGL fractionation, atmospheric crude distillation), Python (NumPy, pandas, numerical methods), and have previously built a spark spread mean-reversion strategy as my first quant portfolio project (using CCGT thermodynamics, OU process, ADF/KPSS tests, z-score signal generation in Jupyter via Anaconda).

---

## THE BIG PICTURE — WHY THIS PROJECT EXISTS

Most crack spread models treat refining margin as a black-box price series. This project derives the product yield weights from a real WTI Light crude assay characterised in Aspen HYSYS, giving the strategy a physical basis that explains *why* the spread mean-reverts rather than just observing that it does.

This is the key differentiator for quant finance applications:
- Everyone has an OU/mean-reversion notebook
- Almost nobody can say "I modelled the underlying physical process that generates this spread"
- The HYSYS simulation replaces the generic textbook 3:2:1 crack spread ratio with simulation-derived yield fractions from a real crude assay

---

## PROJECT STRUCTURE

### Part 1: HYSYS Process Simulation (COMPLETE)
### Part 2: Python Quant Strategy (TO DO — this is what needs to be built next)

---

## PART 1 — WHAT WAS BUILT IN HYSYS (COMPLETE)

### Fluid Package & Components
- Property package: **Peng-Robinson**
- Light ends added: H2, CH4, C2H6, C3H8, i-C4H10, n-C4H10, i-C5H12, n-C5H12, Water

### Crude Assay
- Source: ExxonMobil EMTEC published crude assay "WTI Light" (Reference WTIL220Y, October 2020)
- Citation: ExxonMobil Technology & Engineering Company (EMTEC). Crude Summary Report — WTI Light. Published October 23, 2020.
- Bulk properties: API = 47.5, SG_15/4 = 0.7902, Watson UOPK = 12.25
- Viscosity: 1.72 cP @ 37.78°C, 1.47 cP @ 50°C
- Light ends (wt%): CH4=0.005, C2H6=0.005, C3H8=0.50, i-C4=0.35, n-C4=1.37, i-C5=0.97, n-C5=1.73
- TBP distillation curve (atmospheric, mass basis):
  | Cum wt% | Temp (°C) |
  |---------|-----------|
  | 2.2     | 65        |
  | 8.1     | 100       |
  | 18.4    | 150       |
  | 34.9    | 200       |
  | 47.1    | 250       |
  | 57.4    | 300       |
  | 67.0    | 350       |
  | 78.2    | 370       |

### CDU Flowsheet (Converged)
Topology based on a reference university CDU flowsheet:
**Raw Crude → PreFlash Separator (V-100) → Crude Heater → Mixer → VLV-101 → T-100 (Atmospheric Column)**

Unit operations and key specs:

| Unit Op | Key Specs | Streams |
|---------|-----------|---------|
| Raw Crude stream | 25°C, 200 kPa, 10,000 kg/h, WTI Light composition | — |
| V-100 (3-phase separator) | Adiabatic, 200 kPa, Heat Duty=0 | In: Raw Crude → Out: PreFlsh Liq (9,247 kg/h), PreFlsh Vap (88.84 kg/h), PreFlsh Water (664.1 kg/h) |
| Crude Heater | Outlet T=350°C, ΔP=0 kPa | In: PreFlsh Liq → Out: Hot Crude (9,247 kg/h, 350°C, 200 kPa) |
| MIX-100 (Mixer) | Pressure: Equalize All | In: Hot Crude + Vap Let Down → Out: Atm Feed (9,336 kg/h, 343°C, 150 kPa, vapour=0.783) |
| VLV-101 (valve) | ΔP=50 kPa | In: PreFlsh Vap → Out: Vap Let Down (88.84 kg/h, ~150 kPa) |
| VLV-100 (column feed valve) | ΔP=10 kPa | In: Atm Feed → Out: Col Feed (9,336 kg/h, 342.7°C, 140 kPa) |
| T-100 (Refluxed Absorber) | 28 stages, Partial condenser, P_cond=120 kPa, P_bot=200 kPa, ΔP_cond=0 | Col Feed at stage 24, Main Steam at bottom |
| Main Steam | 250°C, 250 kPa, 250 kg/h, Water=1.0 | Bottom stripping steam |
| Kerosene SS | Reboiled, Draw stage 9, Return stage 8, Draw spec 1.5 m³/h, BoilUp=0.75 | Product: Kerosene |
| Diesel SS | Steam stripped, Draw stage 17, Return stage 16, Draw spec 1.5 m³/h | Steam: Diesel Steam (250°C, 250 kPa, 100 kg/h, Water=1.0); Product: Diesel |
| AGO SS | Steam stripped, Draw stage 22, Return stage 21, Draw spec 1.5 m³/h | Steam: AGO Steam (250°C, 250 kPa, 100 kg/h, Water=1.0); Product: AGO |

### Column Convergence Method (important — took significant effort)
- Solving method: Modified HYSIM Inside-Out
- Fixed Damping Factor: 0.1
- Active specs that achieved convergence: Reflux Ratio=2.0, Condenser Temperature=40°C (stage temperature spec), Kerosene SS Prod Flow=1.5 m³/h, AGO SS Prod Flow=1.5 m³/h, Diesel SS Prod Flow=1.5 m³/h, Kerosene SS BoilUp=0.75
- DO NOT use Distillate Rate + Vap Prod Rate simultaneously as active specs — this causes oscillation and fatal errors in HYSYS for this column configuration

### Converged Product Streams (HYSYS Worksheet output)
| Stream | Mass Flow (kg/h) | Temperature (°C) | Vapour |
|--------|-----------------|-----------------|--------|
| Off Gas | 268.1 | 40 | 1.0 |
| Naphtha | 319.7 | 40 | 0.0 |
| Waste Water | 435.0 | 40 | 0.0 |
| Kerosene | 1,096 | 240 | 0.0 |
| Diesel | 1,142 | 235.1 | 0.0 |
| AGO | 1,172 | 272.1 | 0.0 |
| Residue | 5,353 | 327 | 0.0 |

Mass balance: 9,336 (Col Feed) + 250 + 100 + 100 (steams) = 9,786 kg/h in ≈ 9,786 kg/h out ✓

### HYSYS-Derived Yield Fractions (basis: crude feed only, 9,336 kg/h)
```python
yield_offgas   = 268.1  / 9336   # = 0.0287
yield_naphtha  = 319.7  / 9336   # = 0.0342  → maps to RBOB gasoline (RB=F)
yield_kerosene = 1096   / 9336   # = 0.1174  → jet fuel (not directly traded, informational)
yield_diesel   = 1142   / 9336   # = 0.1223  → maps to Heating Oil (HO=F)
yield_ago      = 1172   / 9336   # = 0.1255  → gasoil/diesel (additional)
yield_residue  = 5353   / 9336   # = 0.5733  → fuel oil/residue
```

Note: Naphtha yield (3.4%) is lower than the WTI Light theoretical ~32% because the column is running conservative specs. This is a real converged HYSYS output and is defensible — noted as a conservative operating point in the README.

### Economics Output (HYSYS Activated Economics)
| Item | Value |
|------|-------|
| Total Capital Cost | $3,625,743 |
| Total Operating Cost/year | $1,383,563 |
| Total Utilities Cost/year | $72,683 |
| Electricity | 75.56 kW, $5.856/h |
| Cooling Water | 0.0203 MMGAL/h, $2.436/h |
| Total utility cost/hour | ~$8.29/h |

**Utility cost per barrel calculation:**
```python
crude_mass_flow  = 9336      # kg/h
crude_density    = 790.2     # kg/m³ (WTI Light at 15°C)
bbl_per_m3       = 6.2898    # barrels per m³
crude_m3_per_hr  = crude_mass_flow / crude_density   # = 11.81 m³/h
crude_bbl_per_hr = crude_m3_per_hr * bbl_per_m3      # = 74.3 bbl/h
utility_cost_per_bbl = 8.29 / 74.3                   # = $0.112/bbl
```

**utility_cost_per_bbl = $0.112/bbl**

---

## PART 2 — WHAT NEEDS TO BE BUILT IN PYTHON (TO DO)

### Environment
- Anaconda Navigator, Jupyter Notebook
- Libraries: yfinance, pandas, numpy, scipy, statsmodels, matplotlib

### GitHub Repo Structure
```
refinery-margin-strategy/
├── hysys/
│   ├── CDU_flowsheet_screenshot.png
│   ├── yield_output.csv
│   └── economics_output.csv
├── notebooks/
│   ├── 01_data_pipeline.ipynb
│   ├── 02_spread_construction.ipynb
│   ├── 03_stationarity_ou_fit.ipynb
│   └── 04_backtest.ipynb
├── src/
│   └── signal_generator.py
├── README.md
└── requirements.txt
```

---

### Notebook 1: Data Pipeline (01_data_pipeline.ipynb)

**Objective:** Pull commodity futures price data from Yahoo Finance

**Tickers:**
```python
import yfinance as yf
import pandas as pd

tickers = {
    'WTI':      'CL=F',   # WTI Crude Oil futures ($/bbl)
    'RBOB':     'RB=F',   # RBOB Gasoline futures ($/gallon)
    'HeatOil':  'HO=F',   # Heating Oil futures ($/gallon)
}

# Pull 5 years of daily data
data = yf.download(list(tickers.values()), start='2019-01-01', end='2024-01-01')['Adj Close']
data.columns = list(tickers.keys())
data = data.dropna()
data.to_csv('../data/raw_prices.csv')
```

**Key note on units:**
- WTI crude: quoted in $/bbl → no conversion needed
- RBOB gasoline: quoted in $/gallon → multiply by 42 to get $/bbl
- Heating Oil: quoted in $/gallon → multiply by 42 to get $/bbl

---

### Notebook 2: Spread Construction (02_spread_construction.ipynb)

**Objective:** Build the physically-grounded crack spread margin series

**The crack spread formula (this is the core differentiator):**
```python
# HYSYS-derived yield fractions
yield_naphtha        = 0.0342   # from HYSYS simulation
yield_diesel         = 0.1223   # from HYSYS simulation
utility_cost_per_bbl = 0.112    # from HYSYS Economics tab

# Convert futures to $/bbl basis
df['RBOB_bbl']     = df['RBOB']    * 42
df['HeatOil_bbl']  = df['HeatOil'] * 42

# Construct margin ($/bbl of crude processed)
df['margin'] = (
      yield_naphtha * df['RBOB_bbl']
    + yield_diesel  * df['HeatOil_bbl']
    - df['WTI']
    - utility_cost_per_bbl
)
```

**Compare against generic 3:2:1 spread for context:**
```python
# Generic 3:2:1 crack spread (textbook version — NOT what we use for trading)
df['crack_321'] = (2/3 * df['RBOB_bbl'] + 1/3 * df['HeatOil_bbl']) - df['WTI']
```

Plot both to show the differentiator visually in the README.

---

### Notebook 3: Stationarity Testing + OU Fit (03_stationarity_ou_fit.ipynb)

**Objective:** Statistically validate mean reversion and fit the OU process

**Step 1 — Stationarity tests:**
```python
from statsmodels.tsa.stattools import adfuller, kpss

# ADF test (null hypothesis: unit root exists = NOT stationary)
adf_result = adfuller(df['margin'], autolag='AIC')
print(f'ADF Statistic: {adf_result[0]:.4f}')
print(f'p-value: {adf_result[1]:.4f}')
# Want: p-value < 0.05 → reject unit root → stationary ✓

# KPSS test (null hypothesis: IS stationary)
kpss_result = kpss(df['margin'], regression='c', nlags='auto')
print(f'KPSS Statistic: {kpss_result[0]:.4f}')
print(f'p-value: {kpss_result[1]:.4f}')
# Want: p-value > 0.05 → fail to reject stationarity ✓
```

**Step 2 — Fit Ornstein-Uhlenbeck process:**
```python
import numpy as np
from scipy.optimize import minimize

# OU process: dX = theta*(mu - X)*dt + sigma*dW
# Discrete form: X(t+1) = X(t) + theta*(mu - X(t))*dt + sigma*sqrt(dt)*epsilon

def ou_log_likelihood(params, X, dt=1):
    theta, mu, sigma = params
    n = len(X) - 1
    X_t  = X[:-1]
    X_t1 = X[1:]
    
    # Expected value and variance of X(t+1) given X(t)
    exp_val = X_t * np.exp(-theta*dt) + mu*(1 - np.exp(-theta*dt))
    var     = (sigma**2 / (2*theta)) * (1 - np.exp(-2*theta*dt))
    
    ll = -n/2 * np.log(2*np.pi*var) - np.sum((X_t1 - exp_val)**2) / (2*var)
    return -ll  # negative because we minimise

X = df['margin'].values
result = minimize(
    ou_log_likelihood, 
    x0=[0.1, X.mean(), X.std()],
    args=(X,),
    method='L-BFGS-B',
    bounds=[(1e-4, None), (None, None), (1e-4, None)]
)

theta, mu, sigma = result.x
half_life = np.log(2) / theta

print(f'Theta (mean reversion speed): {theta:.4f}')
print(f'Mu (long-run mean):           {mu:.4f}')
print(f'Sigma (volatility):           {sigma:.4f}')
print(f'Half-life (days):             {half_life:.1f}')
```

Half-life tells you the practical trading horizon — "this spread takes X days to revert halfway to the mean."

---

### Notebook 4: Signal Generation + Backtest (04_backtest.ipynb)

**Objective:** Generate trading signals and backtest with realistic constraints

**Step 1 — Z-score signal:**
```python
# Rolling z-score (use expanding window or fixed lookback)
lookback = 252  # 1 year rolling window

df['margin_mean'] = df['margin'].rolling(lookback).mean()
df['margin_std']  = df['margin'].rolling(lookback).std()
df['zscore']      = (df['margin'] - df['margin_mean']) / df['margin_std']

# Signal generation
entry_threshold = 1.5
exit_threshold  = 0.0

df['signal'] = 0
df.loc[df['zscore'] < -entry_threshold, 'signal'] =  1  # Long (spread too low)
df.loc[df['zscore'] >  entry_threshold, 'signal'] = -1  # Short (spread too high)
df.loc[df['zscore'].abs() < exit_threshold, 'signal'] = 0  # Exit
df['signal'] = df['signal'].ffill()  # Hold position until exit signal
```

**Step 2 — Operational inertia friction term (THE DIFFERENTIATOR):**
```python
# A refinery can't instantly change yield slate — minimum holding period
min_holding_days = 5  # Operational constraint derived from HYSYS process knowledge

# Apply minimum holding period to signals
def apply_holding_period(signals, min_hold):
    held_signals = signals.copy()
    last_trade_day = -min_hold
    for i in range(len(signals)):
        if signals.iloc[i] != 0 and (i - last_trade_day) < min_hold:
            held_signals.iloc[i] = held_signals.iloc[i-1]  # Hold previous
        elif signals.iloc[i] != 0:
            last_trade_day = i
    return held_signals

df['signal_held'] = apply_holding_period(df['signal'], min_holding_days)
```

**Step 3 — PnL and performance metrics:**
```python
transaction_cost = 0.05  # $/bbl per trade (realistic estimate)

# Daily PnL
df['margin_change'] = df['margin'].diff()
df['pnl_gross']     = df['signal_held'].shift(1) * df['margin_change']

# Transaction costs (apply on signal changes)
df['trade']         = df['signal_held'].diff().abs()
df['pnl_net']       = df['pnl_gross'] - df['trade'] * transaction_cost

# Cumulative equity curve
df['equity_curve']  = df['pnl_net'].cumsum()

# Performance metrics
total_return  = df['pnl_net'].sum()
sharpe_ratio  = df['pnl_net'].mean() / df['pnl_net'].std() * np.sqrt(252)
max_drawdown  = (df['equity_curve'] - df['equity_curve'].cummax()).min()
win_rate      = (df['pnl_net'] > 0).mean()
num_trades    = df['trade'].sum() / 2

print(f'Total Return:    ${total_return:.2f}/bbl')
print(f'Sharpe Ratio:    {sharpe_ratio:.2f}')
print(f'Max Drawdown:    ${max_drawdown:.2f}/bbl')
print(f'Win Rate:        {win_rate:.1%}')
print(f'Number of Trades:{num_trades:.0f}')
```

---

## WHAT NOT TO IMPLEMENT
- No machine learning / neural networks (dilutes the physical-basis story)
- No options pricing (out of scope)
- No live trading infrastructure
- No walk-forward optimisation (simple in-sample/out-of-sample split is enough)

---

## THE NARRATIVE (for README and interviews)

**One-line pitch:**
*"Most crack spread models treat refining margin as a black-box price series — I derived the product yield weights from a real WTI Light crude assay characterised in Aspen HYSYS, giving the strategy a physical basis that explains why the spread mean-reverts rather than just observing that it does."*

**Why this works for each target firm:**
- **Citadel:** Cross-asset (commodities + equities), systematic, defensible physical basis
- **Optiver:** Market making in energy futures — crack spread is a live, traded instrument
- **G-Research:** Quant rigour: OU framework, ADF/KPSS, backtesting with transaction costs
- **Jane Street:** First-principles thinking: understands *why* the spread mean-reverts
- **Qube/Man Group:** Process engineering differentiator — nobody else on the applicant pile has a CDU simulation

---

## CURRENT STATUS
- Part 1 (HYSYS): **COMPLETE** — CDU converged with full product slate
- Part 2 (Python): **TO DO** — start with Notebook 1 (data pipeline)

## CONTINUATION INSTRUCTIONS
Start by building Notebook 1 (data pipeline) in Jupyter via Anaconda Navigator. Use the yield fractions and utility cost per barrel from the HYSYS section above as hardcoded inputs in Notebook 2. Work through all 4 notebooks sequentially. The operational inertia friction term (minimum holding period = 5 days) must be included in the backtest as it directly references the HYSYS process constraints and is the key differentiator vs a generic backtest.

---

## STYLE PREFERENCES
- Keep responses concise and conversational — not polished or scripted
- Step-by-step guidance preferred
- No unsolicited edits to existing code style
- When giving code, provide complete working cells not fragments
- Flag issues directly without excessive preamble
